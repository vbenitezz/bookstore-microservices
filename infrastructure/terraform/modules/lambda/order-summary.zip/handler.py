import json
import os
import psycopg2
import psycopg2.extras

def lambda_handler(event, context):
    """
    Resumen estadístico de órdenes para dashboard administrativo.
    
    GET /reports/orders
    GET /reports/orders?days=30   (últimos N días, default 30)
    
    Retorna:
      - total_orders: número total de órdenes
      - total_revenue: ingresos totales
      - orders_by_status: desglose por estado
      - recent_orders: últimas 10 órdenes
      - daily_revenue: ingresos por día (últimos 7 días)
    """

    params = event.get('queryStringParameters') or {}
    days   = int(params.get('days', 30))

    try:
        conn = psycopg2.connect(
            host     = os.environ['DB_HOST'],
            port     = int(os.environ.get('DB_PORT', 5432)),
            dbname   = os.environ['DB_NAME'],
            user     = os.environ['DB_USER'],
            password = os.environ['DB_PASSWORD'],
            sslmode  = 'require',
            options  = '-c search_path=orders,public'
        )

        cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        # Total y revenue en el período
        cur.execute("""
            SELECT 
                COUNT(*)        AS total_orders,
                COALESCE(SUM(total), 0)::float AS total_revenue,
                COALESCE(AVG(total), 0)::float AS avg_order_value
            FROM orders.orders
            WHERE created_at >= NOW() - INTERVAL '%s days'
        """, (days,))
        summary = dict(cur.fetchone())

        # Órdenes por estado
        cur.execute("""
            SELECT 
                status,
                COUNT(*)        AS count,
                COALESCE(SUM(total), 0)::float AS revenue
            FROM orders.orders
            WHERE created_at >= NOW() - INTERVAL '%s days'
            GROUP BY status
            ORDER BY count DESC
        """, (days,))
        by_status = [dict(r) for r in cur.fetchall()]

        # Últimas 10 órdenes
        cur.execute("""
            SELECT 
                id,
                status,
                total::float,
                shipping_name,
                shipping_email,
                created_at
            FROM orders.orders
            ORDER BY created_at DESC
            LIMIT 10
        """)
        recent = [dict(r) for r in cur.fetchall()]

        # Ingresos por día — últimos 7 días
        cur.execute("""
            SELECT 
                DATE(created_at)        AS day,
                COUNT(*)                AS orders,
                COALESCE(SUM(total), 0)::float AS revenue
            FROM orders.orders
            WHERE created_at >= NOW() - INTERVAL '7 days'
            GROUP BY DATE(created_at)
            ORDER BY day DESC
        """)
        daily = [dict(r) for r in cur.fetchall()]

        cur.close()
        conn.close()

        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'period_days':    days,
                'summary':        summary,
                'by_status':      by_status,
                'recent_orders':  recent,
                'daily_revenue':  daily
            }, default=str)
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'error': str(e)})
        }