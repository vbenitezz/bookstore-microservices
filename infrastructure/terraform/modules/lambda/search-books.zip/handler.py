import json
import os
import psycopg2
import psycopg2.extras

def lambda_handler(event, context):
    """
    Búsqueda de libros en el catálogo.
    
    Query params:
      q         - texto a buscar en título o autor (opcional)
      category  - filtrar por categoría (opcional)
      min_price - precio mínimo (opcional)
      max_price - precio máximo (opcional)
      limit     - máximo de resultados (default: 20)
    
    GET /search?q=clean+code
    GET /search?category=tecnologia&max_price=50
    """
    
    # Obtener parámetros
    params = event.get('queryStringParameters') or {}
    q         = params.get('q', '').strip()
    category  = params.get('category', '').strip()
    min_price = params.get('min_price')
    max_price = params.get('max_price')
    limit     = min(int(params.get('limit', 20)), 100)

    try:
        conn = psycopg2.connect(
            host     = os.environ['DB_HOST'],
            port     = int(os.environ.get('DB_PORT', 5432)),
            dbname   = os.environ['DB_NAME'],
            user     = os.environ['DB_USER'],
            password = os.environ['DB_PASSWORD'],
            sslmode  = 'require',
            options  = '-c search_path=catalog,public'
        )

        cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        # Construir query dinámicamente
        conditions = ["b.is_active = TRUE"]
        values     = []

        if q:
            conditions.append("(b.title ILIKE %s OR b.author ILIKE %s)")
            values.extend([f'%{q}%', f'%{q}%'])

        if category:
            conditions.append("c.slug = %s")
            values.append(category)

        if min_price:
            conditions.append("b.price >= %s")
            values.append(float(min_price))

        if max_price:
            conditions.append("b.price <= %s")
            values.append(float(max_price))

        where = " AND ".join(conditions)
        values.append(limit)

        cur.execute(f"""
            SELECT 
                b.id,
                b.title,
                b.author,
                b.isbn,
                b.price::float,
                b.stock,
                b.cover_url,
                b.language,
                c.name  AS category_name,
                c.slug  AS category_slug
            FROM catalog.books b
            LEFT JOIN catalog.categories c ON b.category_id = c.id
            WHERE {where}
            ORDER BY b.title
            LIMIT %s
        """, values)

        books = cur.fetchall()
        cur.close()
        conn.close()

        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'results': [dict(b) for b in books],
                'count':   len(books),
                'query':   q or None
            }, default=str)
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'error': str(e)})
        }